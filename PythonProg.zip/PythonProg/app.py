from flask import Flask, render_template, request, jsonify
from whois import get_whois

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/search", methods=["POST"])
def search():
    domain = request.json.get("domain")
    if not domain:
        return jsonify({"result": "Домен не указан"}), 400
    result = get_whois(domain)
    return jsonify({"result": result})

if __name__ == "__main__":
    app.run(debug=True)
