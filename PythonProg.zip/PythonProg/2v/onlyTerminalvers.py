import requests
from bs4 import BeautifulSoup
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def get_whois(domain):
    url = "https://whois.nic.kz/cgi-bin/whois"

    session = requests.Session()

    data = {
        "lang": "R",
        "query": domain
    }

    headers = {
        "User-Agent": "Mozilla/5.0"
    }

    response = session.post(url, data=data, headers=headers, verify=False)

    soup = BeautifulSoup(response.text, "html.parser")
    pre = soup.find("pre")

    if not pre:
        return "Домен не найден или сайт ничего не вернул."

    return pre.text.strip()


while True:
    domain = input("\nВведите домен (или 'exit' чтобы выйти): ")

    if domain.lower() == "exit":
        print("Выход.")
        break

    print("\n" + get_whois(domain))
