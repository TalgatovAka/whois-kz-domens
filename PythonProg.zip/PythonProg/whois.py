import requests
from bs4 import BeautifulSoup
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def get_whois(domain):
    url = "https://whois.nic.kz/cgi-bin/whois"
    session = requests.Session()
    data = {"lang": "R", "query": domain}
    headers = {"User-Agent": "Mozilla/5.0"}
    
    response = session.post(url, data=data, headers=headers, verify=False)
    soup = BeautifulSoup(response.text, "html.parser")
    pre = soup.find("pre")
    
    if not pre:
        return "Домен не найден или сайт ничего не вернул."

    # Очистка лишних символов
    cleaned = pre.text.strip()  # убираем пробелы и переносы по краям
    cleaned = "\n".join(line.strip() for line in cleaned.splitlines() if line.strip())  # убираем пустые строки
    return cleaned
