from flask import Flask, render_template, request, jsonify
import socket

app = Flask(__name__, static_folder="static", template_folder="templates")

def fetch_whois(domain: str, host: str = "whois.nic.kz", port: int = 43, timeout: float = 8.0) -> str:
    domain = domain.strip()
    if not domain:
        return "Домен не указан."

    try:
        with socket.create_connection((host, port), timeout=timeout) as sock:
            sock.sendall((domain + "\r\n").encode("utf-8"))
            chunks = []
            while True:
                data = sock.recv(4096)
                if not data:
                    break
                chunks.append(data)
    except Exception as e:
        return f"Ошибка подключения: {e}"

    raw = b"".join(chunks)
    try:
        text = raw.decode("utf-8", errors="replace")  # оставляем мусорные символы, чтобы код не ломался
    except Exception:
        text = str(raw)

    return text

@app.route("/")
def index():
    return render_template("index.html")  # оставляем твой старый HTML

@app.route("/search", methods=["POST"])
def search():
    data = request.get_json(silent=True) or {}
    domain = (data.get("domain") or "").strip()
    if not domain:
        return jsonify({"result": "Домен не указан"}), 400

    result = fetch_whois(domain)
    return jsonify({"result": result})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
